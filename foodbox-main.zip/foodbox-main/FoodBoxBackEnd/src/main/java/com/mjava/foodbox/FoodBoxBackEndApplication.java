package com.mjava.foodbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodBoxBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodBoxBackEndApplication.class, args);
	}

}
